﻿namespace MusicHub.Data;

public static class Configuration
{
    public static string ConnectionString =
			@"Server=DESKTOP-3PGJHFO\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
}
